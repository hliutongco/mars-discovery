import React from 'react';

const Cell = (props) => {
  return (
    <div className="cell"></div>
  )
}

export default Cell;
